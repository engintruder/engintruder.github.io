/*
var es5 = function(one, two) {
    return one + two;
}

var sum = es5(1, 2);
console.log(sum);
*/

/*
let es6 = (one, two)  => {
    return one + two;
};
let result = es6(1, 2);
console.log(result);
*/

/*
let total = (one, two) => one + two;
let result = total(1, 2);
console.log(result);
*/
let total = (one, two) => 
one + two;
let result = total(1, 2);
console.log(result);
