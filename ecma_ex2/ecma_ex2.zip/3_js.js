/*
let one, two;
[one, two] = [1, 2];

console.log(one);
*/

/*
let one, two, three, foru, five;
const values = [1,2,3];

[one, two, three] = values;
console.log("A:" , one, two, three);

[one, two] = values;
console.log("B:", one, two);

[one, two, three, four] = values;
console.log("C:", one, two, three, four);

[one, two, [three, four]] = [1, 2, [73, 74]];
console.log("D:", one,two, three, four);
*/

/*
let {one, two} = {one: 1, nine:9};
console.log(one, two);

let three, four;
({three, four} = {three: 3, four:4});
console.log(three, four);
*/
/*

function total({one, plus: {two, five}}){
    console.log(one + two + five);    
}

total({one: 1, plus: {two: 2, five:5}});


var obj = {
    one : 1, 
    plus: {two: 2, five: 5}
};
total(obj);

*/
