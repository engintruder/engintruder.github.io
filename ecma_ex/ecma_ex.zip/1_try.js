let sports = "축구";
try{
    let sports = "농구";
    console.log(sports);
} catch (e){
    
};
console.log(sports);