var count = 1;
let sports = '축구';
switch (count){
    case 1: 
        let sports = '농구';
        console.log(sports;
};