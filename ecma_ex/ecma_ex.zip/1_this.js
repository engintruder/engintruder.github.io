var music = "음악";
console.log(this.music);

let sports = "축구";
console.log(this.sports);