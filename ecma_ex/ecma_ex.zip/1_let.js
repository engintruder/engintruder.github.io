'use strict';
let book;
let sports = '축구';
sports = '농구';

let one = 1, two = 2, three;
//let four = 4, let five =5;            //error
//let six = 6, var seven = 7;           //error