let sports = "축구", music = "재즈";
function get(){
    let music = "클래식";
    console.log(music);
    console.log(sports);
}
get();