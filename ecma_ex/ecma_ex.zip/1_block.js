let sports = '축구';
if (sports){
    let sports = '농구';
    console.log("블록:" , sports);
}
console.log("글로벌:" , sports);