console.log(sports);
var sports = "스포츠";

console.log(music);
let music = "음악";